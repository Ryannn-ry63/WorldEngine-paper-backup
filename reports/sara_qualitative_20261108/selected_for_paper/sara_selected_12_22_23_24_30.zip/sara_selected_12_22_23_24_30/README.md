# SARA 论文定性案例：12、22、23、24、30

这是一份可独立转交和修改的绘图包。解压后无需服务器、仿真器、地图 SDK、模型权重或原始数据集；只需要 Python、NumPy、Matplotlib 和 Pillow。默认图片不画箭头。

## 先看哪些文件

- `overview.jpg`：五个案例的总览，保留原编号。
- `figures/`：每个案例的 PNG、PDF、SVG；论文排版建议使用 PDF，SVG 也可在矢量软件中编辑。
- `animations/`：每个案例的闭环动图；30 建议结合动图看冲突车辆。
- `context/`：前视图，上排 Base、下排 SARA，三列为 t=0 / 2 / 4 秒。
- `plot_cases.py`：静态绘图代码，**直接修改此文件顶部的 `STYLE` 即可改图**。
- `animate_cases.py`：动图代码，沿用 `plot_cases.py` 的配色、字体和坐标配置。
- `data/`：完整绘图数据，包括地图、自车轨迹、速度、车辆朝向及每帧周围车辆轮廓。
- `metrics.csv`、`manifest.json`：正式指标与场景标识；`verification.json` 记录核验情况。

## 三类展示意图

| 编号 | 类型 | 观察到的差异 | 主要指标 |
|---|---|---|---|
| 12 | 车道保持 | Base 道路合规失败，SARA 保持在道路范围内；视觉差异相对细微 | DAC |
| 22 | 闭环中的持续推进 | Base 逐渐停滞，SARA 持续向前行驶 | EP |
| 23 | 闭环中的起步推进 | Base 在路口前低速停滞，SARA 向路口内继续推进 | EP |
| 24 | 闭环中的低速恢复 | Base 一直低速，SARA 减速后恢复推进 | EP |
| 30 | 转弯冲突避让 | Base 继续左转并与冲突车辆相撞，SARA 提前制动 | NC、TTC |

22–24 的类型相近，适合从中挑一两张放论文。它们可用于展示在线后训练模型在闭环中的推进表现，但这组图本身不能证明 Base 停滞的具体内部原因。Base 和 SARA **都接受闭环评测**，不应写成“Base 是开环评测”。

30 展示的是潜在冲突出现时两种模型的行为分化：Base 在约 2.5–3.0 秒已出现几何接触，正式 NC/TTC 也失败；SARA 提前制动。SARA 在这四秒里基本停住，不能据此描述为已经完成左转、或者已经确认其之后能顺利起步。12 的正式指标是 DAC（道路可行驶区域合规），不等于单独测量了车道居中误差。

## 如何运行

建议 Python 3.10 或以上。先切换到解压后的本文件所在目录：

```bash
python -m pip install -r requirements.txt
python plot_cases.py
```

默认重新生成五个案例的 PNG / PDF / SVG，写入 `figures/`。也可以只画选中的案例、指定格式或另存目录：

```bash
python plot_cases.py --cases 12 30 --formats png pdf svg --output my_figures
python animate_cases.py --cases 30
```

代码按自身所在目录读取数据，不依赖终端当前路径。Windows 可按本机环境将 `python` 换成 `py`。

## 怎么改 Python 来改图

打开 `plot_cases.py`，找到顶部的 `STYLE = {...}`。该配置会直接生效；不用额外修改 JSON 配置文件。

| 想改的内容 | 修改位置 |
|---|---|
| 字号、字体 | `STYLE['font_size']`、`STYLE['font_family']` |
| Base / SARA 颜色与显示名 | `STYLE['colors']`、`STYLE['model_labels']` |
| 图的大小与 PNG 清晰度 | `figsize_with_speed`、`figsize_bev`、`dpi` |
| 只保留左右轨迹图 | `show_speed` 改为 `False` |
| 隐藏标题、底部说明、分数 | `show_title`、`show_footer`、`show_scores` 改为 `False` |
| 轨迹线宽、点大小 | `trajectory_linewidth`、`marker_size` |
| 显示哪些时刻的周围车辆 | `actor_frames`；0–8 对应 0–4 秒，间隔 0.5 秒 |
| 自车轮廓密度 | `footprint_stride`；2 表示每秒显示一个 |
| 单张图的标题和坐标范围 | `case_overrides` 中对应编号的 `title`、`xlim`、`ylim` |
| 更复杂的布局、图层和标注 | 修改 `draw_case()`、`draw_map()` 函数 |

例如在 `STYLE['case_overrides']['30']` 中增加：

```python
'30': {
    'title': 'Turning conflict avoidance',
    'xlim': [-8, 35],
    'ylim': [-10, 30],
},
```

随后运行 `python plot_cases.py --cases 30`。若要使用中文标题，需要将 `font_family` 改成电脑上已安装的中文字体。绘图文件均可编辑，但建议保留 `data/` 原始轨迹和指标以便核对。

## 数据口径

五个案例均来自同一对正式模型：NavTrain50 Base 与 SARA online rare-log、seed 0、epoch 2；均展示 **R 模式**。每个案例两种模型具有相同的初始自车和环境状态。

轨迹是实际记录的四秒闭环执行，九个采样点、间隔 0.5 秒；不是预测轨迹。动图也只使用这九帧，最后一帧延长显示以便观察，没有补造四秒后的结果。坐标以初始后轴为原点，x 为初始车头方向，y 为左侧，单位米；速度为 m/s；图中指标统一乘以 100，原始 JSON 保留 0–1 值。

前视图来自仿真渲染，可能存在伪影，适合辅助理解场景。四秒结果不代表之后必然安全。这里按照已选案例展示，不用于替代全量评测或单项奖励消融结论。
