"""重画闭环动图：python animate_cases.py --cases 30；默认画全部五例。"""
import argparse,copy,io,json
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from PIL import Image
from plot_cases import STYLE,draw_map,footprint
HERE=Path(__file__).resolve().parent

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--cases',type=int,nargs='+',default=[12,22,23,24,30]);parser.add_argument('--output',type=Path,default=HERE/'animations');args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
 style=copy.deepcopy(STYLE);plt.rcParams.update({'font.family':style['font_family'],'font.size':style['font_size']})
 for n in args.cases:
  data=json.loads((HERE/'data'/f'case_{n:02d}.json').read_text(encoding='utf-8'));models=data['models'];allxy=np.concatenate([m['local_xy'] for m in models.values()]);lo=allxy.min(0)-10;hi=allxy.max(0)+12;lo[1]=min(lo[1],-10);hi[1]=max(hi[1],12);frames=[];custom=style.get('case_overrides',{}).get(str(n),{})
  for i in range(9):
   fig,axs=plt.subplots(1,2,figsize=style['figsize_bev'])
   for ax,name in zip(axs,['Base','SARA']):
    draw_map(ax,data,style);m=models[name];xy=np.array(m['local_xy']);color=style['colors'][name]
    for p in m['actors'][i]:ax.add_patch(Polygon(p,fc=style['actor_fill'],ec=style['actor_edge'],alpha=.65,lw=.5,zorder=2))
    ax.plot(xy[:i+1,0],xy[:i+1,1],'-o',c=color,lw=style['trajectory_linewidth'],ms=style['marker_size'],zorder=4);ax.add_patch(Polygon(footprint(xy[i],m['yaw_local'][i]),fc=color,ec=color,alpha=.65,zorder=5))
    ax.set(xlim=custom.get('xlim',[lo[0],hi[0]]),ylim=custom.get('ylim',[lo[1],hi[1]]),xlabel='Longitudinal (m)',ylabel='Lateral (m)',title=f'{style["model_labels"][name]} | t={i*.5:.1f} s | v={m["speed_mps"][i]:.1f} m/s');ax.set_aspect('equal');ax.spines[['top','right']].set_visible(False)
   if style['show_title']:fig.suptitle(custom.get('title',f'{n} | {data["title"]}'),fontweight='bold')
   if style['show_footer']:fig.text(.5,.015,'Recorded poses and actors every 0.5 s; gray = other actors.',ha='center',fontsize=8)
   fig.tight_layout(rect=(0,.09,1,.94));buf=io.BytesIO();fig.savefig(buf,format='png',dpi=110);plt.close(fig);buf.seek(0);frames.append(Image.open(buf).convert('RGB'))
  # 九帧均为真实记录；最后一帧多停留一秒，便于看清结果。
  frames[0].save(args.output/f'case_{n:02d}.gif',save_all=True,append_images=frames[1:],duration=[500]*8+[1500],loop=0);print('Animated',n,flush=True)
if __name__=='__main__':main()
