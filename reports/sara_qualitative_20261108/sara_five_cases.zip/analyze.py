"""Screen formal paired results and plot recorded closed-loop ego motion."""
import csv
import hashlib
import json
import sqlite3
from pyproj import Transformer
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
import geopandas as gpd
from safe_metadata import read_metadata

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
ARCHIVE = ROOT / 'research/selector_paper_assets_seed0_20261018'
MAPS = ROOT / 'local_data/views/roboticsystem2_20261011/raw/nuplan/dataset/maps'
METHODS = {'Base':'base', 'SARA':'online_rarelog_s0_b16_e2'}
COLORS = {'Base':'#cc4c3b','SARA':'#197bbd'}
METRICS = ['score','no_at_fault_collisions','drivable_area_compliance','time_to_collision_within_bound','ego_progress']


def read_results():
    results = {}
    for name, method in METHODS.items():
        for mode in ('R','NR'):
            folder = ARCHIVE/'rows'/method/'evaluation'/('closed_'+mode)
            d = json.loads((folder/'accepted.json').read_text())
            assert hashlib.sha256((folder/'pdm.csv').read_bytes()).hexdigest() == d['files_sha256']['pdm']
            d['csv'] = {r['token']:r for r in csv.DictReader((folder/'pdm.csv').open()) if r['token'] in d['rows']}
            d['source'] = str(folder/'accepted.json')
            results[name,mode] = d
    for mode in ('R','NR'):
        assert results['Base',mode]['rows'].keys() == results['SARA',mode]['rows'].keys()
        assert len(results['Base',mode]['rows']) == 288
    return results


def metadata_path(result, scene):
    attempt = Path(result['attempt'].replace('/nry/','/WE_related/'))
    return attempt/'simulation/WE_output/openscene_format/meta_datas'/(scene+'.pkl')


def yaw(frame):
    w,x,y,z = frame['ego2global_rotation']
    return np.arctan2(2*(w*z+x*y), 1-2*(y*y+z*z))


def transform(xy, origin, heading):
    c,s = np.cos(heading), np.sin(heading)
    return (np.asarray(xy)[...,:2]-origin) @ np.array([[c,-s],[s,c]])


def footprint(xy, theta, length=5.176, width=2.297, rear_axle=True):
    c,s = np.cos(theta),np.sin(theta)
    corners=np.array([[length/2,width/2],[length/2,-width/2],[-length/2,-width/2],[-length/2,width/2]])
    if rear_axle: corners[:,0]+=1.461
    return corners @ np.array([[c,s],[-s,c]]) + xy


def vector_map(frames):
    xy=np.concatenate([np.asarray([f['ego2global_translation'][:2] for f in fs[3:]]) for fs in frames.values()])
    lo,hi=xy.min(0)-22,xy.max(0)+22
    location=frames['Base'][3]['map_location']
    gpkg=next((MAPS/location).glob('*/map.gpkg'))
    with sqlite3.connect('file:'+str(gpkg.resolve())+'?mode=ro',uri=True) as conn:
        projection=conn.execute("select value from meta where key='projectedCoordSystem'").fetchone()[0]
    bbox=Transformer.from_crs(projection,'EPSG:4326',always_xy=True).transform_bounds(*lo,*hi)
    layers={}
    for layer in ('lanes_polygons','intersections','carpark_areas','boundaries','baseline_paths','crosswalks'):
        layers[layer]=gpd.read_file(gpkg,layer=layer,bbox=bbox,engine='pyogrio').to_crs(projection)
    assert len(layers['lanes_polygons']) > 0, 'Empty map crop'
    return layers


def draw_map(ax,layers,origin,heading):
    for layer,gdf in layers.items():
        for geom in gdf.geometry:
            if geom is None: continue
            geoms=list(geom.geoms) if geom.geom_type.startswith('Multi') else [geom]
            for g in geoms:
                if g.geom_type=='Polygon':
                    xy=transform(g.exterior.coords,origin,heading)
                    ax.add_patch(Polygon(xy,facecolor='#eef0f2' if layer!='crosswalks' else '#e0e3e6',edgecolor='#d0d4d8',lw=.45,zorder=0))
                elif g.geom_type=='LineString':
                    xy=transform(g.coords,origin,heading)
                    ax.plot(xy[:,0],xy[:,1],color='#c2c7cc',lw=.65,ls='--' if layer=='baseline_paths' else '-',zorder=1)


def extract_scene(results,scene):
    frames={name:read_metadata(metadata_path(results[name,'R'],scene)) for name in METHODS}
    assert all(len(fs)==12 for fs in frames.values())
    a,b=frames.values()
    assert np.array_equal([f['timestamp'] for f in a],[f['timestamp'] for f in b])
    assert np.allclose([f['ego2global_translation'] for f in a[:4]],[f['ego2global_translation'] for f in b[:4]],atol=1e-8,rtol=0)
    assert np.allclose(a[3]['anns']['gt_boxes'],b[3]['anns']['gt_boxes'],atol=1e-7,rtol=0)
    return frames


def plot_scene(results,scene,category,number,frames,layers):
    origin=frames['Base'][3]['ego2global_translation'][:2];heading=yaw(frames['Base'][3])
    poses={n:transform([f['ego2global_translation'][:2] for f in fs[3:]],origin,heading) for n,fs in frames.items()}
    allxy=np.concatenate(list(poses.values()));lo=allxy.min(0)-7;hi=allxy.max(0)+8
    # Keep lateral context and a consistent scale within a scene.
    lo[1]=min(lo[1],-9);hi[1]=max(hi[1],9)
    fig,axs=plt.subplots(1,3,figsize=(15,5),gridspec_kw={'width_ratios':[1,1,.9]})
    for ax,name in zip(axs[:2],METHODS):
        draw_map(ax,layers,origin,heading)
        fs=frames[name];xy=poses[name]
        # Actors shown at start and final time; intervening positions on review animation.
        for j,alpha in [(3,.16),(11,.5)]:
            f=fs[j];fxy=transform([f['ego2global_translation'][:2]],origin,heading)[0];ang=yaw(f)-heading
            for box in f['anns']['gt_boxes']:
                c,s=np.cos(ang),np.sin(ang);center=box[:2] @ np.array([[c,s],[-s,c]])+fxy
                if np.all(center>lo-5) and np.all(center<hi+5):
                    ax.add_patch(Polygon(footprint(center,ang+box[6],box[3],box[4],False),fc='#9099a3',ec='#626a73',alpha=alpha,lw=.5,zorder=2))
        ax.plot(xy[:,0],xy[:,1],'-o',c=COLORS[name],lw=2,ms=3.5,zorder=4)
        for i in (0,2,4,6,8):
            poly=footprint(xy[i],yaw(fs[i+3])-heading)
            ax.add_patch(Polygon(poly,fc=COLORS[name],ec=COLORS[name],alpha=.12+.035*i,lw=.7,zorder=3))
        ax.scatter(*xy[0],marker='s',s=28,c='black',zorder=6)
        row=results[name,'R']['rows'][scene]
        ax.set_title(f'{name}   PDM {100*row["score"]:.1f}',fontsize=12,fontweight='bold')
        ax.set(xlim=(lo[0],hi[0]),ylim=(lo[1],hi[1]),xlabel='Initial-heading longitudinal axis (m)',ylabel='Lateral axis (m)')
        ax.set_aspect('equal');ax.spines[['top','right']].set_visible(False)
    ax=axs[2]
    for name,fs in frames.items():
        speed=np.array([np.linalg.norm(f['ego_dynamic_state'][:2]) for f in fs[3:]])
        ax.plot(np.arange(9)*.5,speed,'-o',c=COLORS[name],label=name,ms=4,lw=2)
    ax.set(xlabel='Closed-loop time (s)',ylabel='Speed (m/s)',xlim=(0,4));ax.grid(alpha=.2);ax.legend(loc='upper right');ax.spines[['top','right']].set_visible(False)
    lines=['Formal R metrics (0–100)', '                 Base      SARA']
    for label,key in [('NC','no_at_fault_collisions'),('DAC','drivable_area_compliance'),('TTC','time_to_collision_within_bound'),('EP','ego_progress')]:
        lines.append(f'{label:<7} {results["Base","R"]["rows"][scene][key]*100:8.1f} {results["SARA","R"]["rows"][scene][key]*100:9.1f}')
    ax.text(.03,.03,'\n'.join(lines),transform=ax.transAxes,fontfamily='monospace',fontsize=9,bbox={'fc':'white','alpha':.85,'ec':'#dddddd'})
    fig.suptitle(f'{number:02d} | {category} | {scene.rsplit("-",1)[-1]}',fontsize=14,fontweight='bold')
    fig.text(.5,.015,'Recorded 4 s closed-loop motion; dots every 0.5 s; footprints every 1 s. Gray actors: t=0 (faint), t=4 s (dark).',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.045,1,.94));fig.savefig(OUT/f'preview_{number:02d}.png',dpi=150);plt.close(fig)


def main():
    results=read_results();rows=[];summary={}
    for mode in ('R','NR'):
        b=results['Base',mode]['rows'];s=results['SARA',mode]['rows']
        summary[mode]={'n':288,'improved':sum(s[k]['score']>b[k]['score']+1e-5 for k in b),'regressed':sum(s[k]['score']<b[k]['score']-1e-5 for k in b),'metrics':{}}
        for m in METRICS[1:4]:
            summary[mode]['metrics'][m]={'repaired':sum(b[k][m]<1 and s[k][m]==1 for k in b),'new_failures':sum(b[k][m]==1 and s[k][m]<1 for k in b)}
        for scene in b:
            row={'scene':scene,'mode':mode,'delta_score':s[scene]['score']-b[scene]['score']}
            for name,d in [('Base',b),('SARA',s)]:
                for m in METRICS: row[name+'_'+m]=d[scene][m]
            rows.append(row)
    with (OUT/'paired_scores.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (OUT/'paired_summary.json').write_text(json.dumps(summary,indent=2))
    b=results['Base','R']['rows'];s=results['SARA','R']['rows'];candidates=[]
    for category in ('Collision repair','Road compliance repair','Progress improvement'):
        pool=[]
        for scene in b:
            rb,rs=b[scene],s[scene]
            if not all(rs[m]==1 for m in METRICS[1:4]) or rs['score']<.8:continue
            if category=='Collision repair' and rb['no_at_fault_collisions']>=1:continue
            if category=='Road compliance repair' and not (rb['drivable_area_compliance']==0 and rb['no_at_fault_collisions']==1):continue
            if category=='Progress improvement' and not all(rb[m]==1 for m in METRICS[1:4]):continue
            pool.append(scene)
        pool.sort(key=lambda k:s[k]['score']-b[k]['score'],reverse=True)
        logs=set()
        for scene in pool:
            log=scene.rsplit('-',1)[0]
            if log in logs:continue
            logs.add(log);candidates.append((scene,category))
            if len(logs)==4:break
    manifest=[]
    for i,(scene,category) in enumerate(candidates,1):
        print('preview',i,scene,flush=True)
        frames=extract_scene(results,scene);layers=vector_map(frames)
        plot_scene(results,scene,category,i,frames,layers)
        record={'preview':i,'scene':scene,'category':category,'mode':'R','metadata':{},'metrics':{}}
        for name in METHODS:
            p=metadata_path(results[name,'R'],scene)
            record['metadata'][name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
            record['metrics'][name]={mode:results[name,mode]['rows'][scene] for mode in ('R','NR')}
        record['initial_ego_and_actors_match']=True
        manifest.append(record)
    (OUT/'screening_manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(summary,indent=2))


if __name__=='__main__': main()
