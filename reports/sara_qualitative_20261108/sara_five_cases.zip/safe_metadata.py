"""Read numeric metadata without importing or invoking any pickle globals.

GLOBAL/REDUCE/BUILD are interpreted as inert records. Only explicit NumPy
numeric/string array recipes are converted from raw bytes after parsing.
Unknown opcodes and object arrays fail closed. No pickle.load is used.
"""
from pathlib import Path
import pickletools
import numpy as np


class Record:
    def __init__(self, symbol, args=()):
        self.symbol, self.args, self.state = symbol, args, None


def read_metadata(path):
    stack, memo = [], {}
    mark = object()

    def marked():
        i = next(i for i in range(len(stack)-1, -1, -1) if stack[i] is mark)
        values = stack[i+1:]
        del stack[i:]
        return values

    for op, arg, _ in pickletools.genops(Path(path).read_bytes()):
        n = op.name
        if n in ('PROTO', 'FRAME'):
            continue
        if n == 'STOP':
            break
        if n == 'MARK': stack.append(mark)
        elif n == 'NONE': stack.append(None)
        elif n == 'NEWTRUE': stack.append(True)
        elif n == 'NEWFALSE': stack.append(False)
        elif n in ('BININT', 'BININT1', 'BININT2', 'LONG1', 'LONG4', 'INT', 'LONG',
                   'BINFLOAT', 'FLOAT', 'SHORT_BINUNICODE', 'BINUNICODE', 'BINUNICODE8',
                   'SHORT_BINBYTES', 'BINBYTES', 'BINBYTES8', 'BYTEARRAY8'):
            stack.append(arg)
        elif n == 'EMPTY_LIST': stack.append([])
        elif n == 'EMPTY_DICT': stack.append({})
        elif n == 'EMPTY_TUPLE': stack.append(())
        elif n == 'MEMOIZE': memo[len(memo)] = stack[-1]
        elif n in ('BINPUT', 'LONG_BINPUT', 'PUT'): memo[int(arg)] = stack[-1]
        elif n in ('BINGET', 'LONG_BINGET', 'GET'): stack.append(memo[int(arg)])
        elif n == 'APPENDS':
            vals = marked(); stack[-1].extend(vals)
        elif n == 'APPEND':
            val = stack.pop(); stack[-1].append(val)
        elif n == 'SETITEMS':
            vals = marked(); stack[-1].update(zip(vals[::2], vals[1::2]))
        elif n == 'SETITEM':
            val, key = stack.pop(), stack.pop(); stack[-1][key] = val
        elif n == 'TUPLE': stack.append(tuple(marked()))
        elif n in ('TUPLE1', 'TUPLE2', 'TUPLE3'):
            count = int(n[-1]); vals = tuple(stack[-count:]); del stack[-count:]; stack.append(vals)
        elif n == 'STACK_GLOBAL':
            name, module = stack.pop(), stack.pop(); stack.append(Record((module, name)))
        elif n == 'GLOBAL': stack.append(Record(tuple(arg.split(' '))))
        elif n == 'REDUCE':
            args, symbol = stack.pop(), stack.pop()
            if not isinstance(symbol, Record): raise ValueError('Invalid symbol')
            stack.append(Record(symbol.symbol, args))
        elif n == 'BUILD':
            state = stack.pop()
            if not isinstance(stack[-1], Record): raise ValueError('Invalid state target')
            stack[-1].state = state
        else:
            raise ValueError('Unsupported inert opcode: '+n)
    if len(stack) != 1: raise ValueError('Invalid final stack')

    def decode(x):
        if isinstance(x, Record):
            module, name = x.symbol
            if module == 'numpy' and name == 'dtype':
                d = np.dtype(x.args[0])
                if d.hasobject or d.fields: raise ValueError('Object/structured dtype denied')
                if x.state and x.state[1] in ('<','>','='): d = d.newbyteorder(x.state[1])
                return d
            if module in ('numpy.core.multiarray','numpy._core.multiarray') and name == '_reconstruct':
                version, shape, dtype, fortran, raw = x.state
                dtype = decode(dtype)
                if not isinstance(raw, bytes): raise ValueError('Only raw-byte arrays allowed')
                return np.frombuffer(raw, dtype=dtype).reshape(shape, order='F' if fortran else 'C')
            if module in ('numpy.core.multiarray','numpy._core.multiarray') and name == 'scalar':
                return np.frombuffer(x.args[1], dtype=decode(x.args[0]))[0]
            raise ValueError('Unsupported inert recipe: '+str(x.symbol))
        if isinstance(x, dict): return {k:decode(v) for k,v in x.items()}
        if isinstance(x, list): return [decode(v) for v in x]
        if isinstance(x, tuple): return tuple(decode(v) for v in x)
        return x
    return decode(stack[0])
