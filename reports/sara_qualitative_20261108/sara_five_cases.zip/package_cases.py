"""Package five reviewed cases with static plots, time-aligned BEV GIFs and evidence."""
import io,json,shutil,zipfile
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from PIL import Image,ImageDraw
from analyze import OUT,ROOT,ARCHIVE,METHODS,COLORS,read_results,extract_scene,vector_map,draw_map,transform,yaw,footprint,plot_scene

SELECTION=[(1,'跟车减速，避免碰撞','Safe following'),(7,'道路走向处纠偏（R 模式）','Road alignment'),(8,'沿弯道继续行驶','Following road curvature'),(12,'路口右转推进','Right-turn progress'),(9,'解除低速停滞','Recovery from low progress')]

def main():
    results=read_results();screen=json.loads((OUT/'screening_manifest.json').read_text());selected=[]
    for number,(preview,title,english) in enumerate(SELECTION,1):
        record=screen[preview-1];scene=record['scene'];frames=extract_scene(results,scene);layers=vector_map(frames)
        print(number,scene,flush=True)
        record.update(number=number,title_zh=title,title_en=english,artifacts={})
        # Preserve original 12-case screening previews. Generate final numbering separately.
        fig_path=OUT/f'case_{number:02d}.png'
        old=OUT/f'preview_{number:02d}.png';backup=old.read_bytes()
        plot_scene(results,scene,english,number,frames,layers)
        shutil.copyfile(old,fig_path);old.write_bytes(backup)
        origin=frames['Base'][3]['ego2global_translation'][:2];heading=yaw(frames['Base'][3])
        poses={n:transform([f['ego2global_translation'][:2] for f in fs[3:]],origin,heading) for n,fs in frames.items()}
        allxy=np.concatenate(list(poses.values()));lo=allxy.min(0)-7;hi=allxy.max(0)+8;lo[1]=min(lo[1],-9);hi[1]=max(hi[1],9)
        animation=[];trace={'scene':scene,'mode':'R','t_zero_frame_idx':3,'models':{}}
        for name,fs in frames.items():
            speeds=[float(np.linalg.norm(f['ego_dynamic_state'][:2])) for f in fs[3:]]
            trace['models'][name]={'global_xy':[f['ego2global_translation'][:2].tolist() for f in fs[3:]],'local_xy':poses[name].tolist(),'yaw_global':[float(yaw(f)) for f in fs[3:]],'speed_mps':speeds,'timestamp_us':[int(f['timestamp']) for f in fs[3:]],'frame_idx':[int(f['frame_idx']) for f in fs[3:]]}
            record.setdefault('motion',{})[name]={'distance_m':float(np.linalg.norm(np.diff(poses[name],axis=0),axis=1).sum()),'final_speed_mps':speeds[-1]}
        for step in range(9):
            fig,axs=plt.subplots(1,2,figsize=(11,4.4))
            for ax,name in zip(axs,METHODS):
                draw_map(ax,layers,origin,heading);fs=frames[name];xy=poses[name];f=fs[step+3];ang=yaw(f)-heading
                for box in f['anns']['gt_boxes']:
                    c,s=np.cos(ang),np.sin(ang);center=box[:2] @ np.array([[c,s],[-s,c]])+xy[step]
                    if np.all(center>lo-5) and np.all(center<hi+5):
                        ax.add_patch(Polygon(footprint(center,ang+box[6],box[3],box[4],False),fc='#89929c',ec='#59636e',alpha=.85,lw=.65,zorder=3))
                ax.plot(xy[:step+1,0],xy[:step+1,1],'-o',c=COLORS[name],lw=2,ms=3,zorder=4)
                ax.add_patch(Polygon(footprint(xy[step],ang),fc=COLORS[name],ec='#222222',alpha=.85,lw=.8,zorder=5))
                ax.scatter(*xy[0],marker='s',s=15,c='black',zorder=6)
                score=record['metrics'][name]['R']['score']*100
                ax.set_title(f'{name} | episode PDM {score:.1f} | v={trace["models"][name]["speed_mps"][step]:.1f} m/s',fontsize=11)
                ax.set(xlim=(lo[0],hi[0]),ylim=(lo[1],hi[1]),xlabel='Longitudinal axis (m)',ylabel='Lateral axis (m)');ax.set_aspect('equal');ax.spines[['top','right']].set_visible(False)
            fig.suptitle(f'{number:02d} | {english} | t = {step*.5:.1f} s',fontweight='bold',fontsize=13)
            fig.text(.5,.025,'Actual recorded ego and traffic states at the same time; reactive traffic evolves separately in each rollout.',ha='center',fontsize=9)
            fig.tight_layout(rect=(0,.055,1,.94));buf=io.BytesIO();fig.savefig(buf,format='png',dpi=110);plt.close(fig);buf.seek(0);animation.append(Image.open(buf).convert('RGB'))
        animation[0].save(OUT/f'case_{number:02d}.gif',save_all=True,append_images=animation[1:],duration=[500]*8+[1800],loop=0)
        # Actual rendered front-camera context at t=0,2,4 s, with model-specific traffic.
        camera_canvas=Image.new('RGB',(1200,510),'white');draw=ImageDraw.Draw(camera_canvas)
        camera_sources=[]
        for row,name in enumerate(METHODS):
            meta=Path(record['metadata'][name]['path'])
            for col,idx in enumerate([3,7,11]):
                f=frames[name][idx];p=meta.parents[1]/'sensor_blobs'/f['cams']['CAM_F0']['data_path']
                camera_sources.append(str(p));im=Image.open(p).convert('RGB');im.thumbnail((400,225));camera_canvas.paste(im,(col*400,row*255+25));draw.text((col*400+8,row*255+7),f'{name}   t={(idx-3)*.5:.1f}s',fill='black')
        camera_canvas.save(OUT/f'case_{number:02d}_camera.jpg',quality=92)
        record['camera_sources']=camera_sources
        (OUT/f'case_{number:02d}_trajectory.json').write_text(json.dumps(trace,indent=2))
        record['artifacts']={k:f'case_{number:02d}{suffix}' for k,suffix in [('figure','.png'),('animation','.gif'),('camera','_camera.jpg'),('trajectory','_trajectory.json')]}
        selected.append(record)
    (OUT/'selected_cases.json').write_text(json.dumps({'selection':'Post-hoc qualitative illustrations, not an independent evaluation set.','base_model_sha256':results['Base','R']['materialized_sha256'],'sara_model_sha256':results['SARA','R']['materialized_sha256'],'results_sources':{name:{mode:results[name,mode]['source'] for mode in ('R','NR')} for name in METHODS},'cases':selected},indent=2,ensure_ascii=False))
    # Printable selection sheet (two BEV panels only; detailed speed plots stay in case PNGs).
    fig,axs=plt.subplots(5,2,figsize=(13,17))
    for row,r in enumerate(selected):
        frames=extract_scene(results,r['scene']);layers=vector_map(frames);origin=frames['Base'][3]['ego2global_translation'][:2];heading=yaw(frames['Base'][3])
        poses={n:transform([f['ego2global_translation'][:2] for f in fs[3:]],origin,heading) for n,fs in frames.items()};xyall=np.concatenate(list(poses.values()));lo=xyall.min(0)-6;hi=xyall.max(0)+7
        lo[1]=min(lo[1],-6);hi[1]=max(hi[1],6)
        for col,name in enumerate(METHODS):
            ax=axs[row,col];draw_map(ax,layers,origin,heading);xy=poses[name];fs=frames[name]
            for i in [0,2,4,6,8]:ax.add_patch(Polygon(footprint(xy[i],yaw(fs[i+3])-heading),fc=COLORS[name],ec=COLORS[name],alpha=.13+.035*i,lw=.6))
            f=fs[-1];ang=yaw(f)-heading;c,s=np.cos(ang),np.sin(ang)
            for box in f['anns']['gt_boxes']:
                center=box[:2]@np.array([[c,s],[-s,c]])+xy[-1]
                if np.all(center>lo-4) and np.all(center<hi+4):ax.add_patch(Polygon(footprint(center,ang+box[6],box[3],box[4],False),fc='#9ba3ac',ec='#727b85',alpha=.65,lw=.5))
            ax.plot(xy[:,0],xy[:,1],'-o',color=COLORS[name],ms=3,lw=2);ax.scatter(*xy[0],marker='s',color='black',s=20)
            ax.set_title(f'{row+1}. {r["title_en"]} | {name}: {r["metrics"][name]["R"]["score"]*100:.1f}',fontsize=11,fontweight='bold')
            ax.set(xlim=(lo[0],hi[0]),ylim=(lo[1],hi[1]));ax.set_aspect('equal');ax.spines[['top','right']].set_visible(False);ax.tick_params(labelsize=8)
    fig.suptitle('Five qualitative candidates | Base vs SARA | Reactive closed-loop evaluation',fontsize=15,fontweight='bold')
    fig.text(.5,.01,'Axes in meters. Entire 4 s executed rear-axle path; dots every 0.5 s; footprints every 1 s. Gray actors at t=4 s only.',ha='center',fontsize=10)
    fig.tight_layout(rect=(0,.025,1,.97));fig.savefig(OUT/'five_cases_overview.png',dpi=160);fig.savefig(OUT/'five_cases_overview.pdf');plt.close(fig)
    print('done',flush=True)

if __name__=='__main__':main()
